exports.index = function(req, res) {
	res.render("login.ejs");
}